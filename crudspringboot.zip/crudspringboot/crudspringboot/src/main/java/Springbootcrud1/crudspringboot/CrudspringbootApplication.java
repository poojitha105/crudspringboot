package Springbootcrud1.crudspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudspringbootApplication.class, args);
	}

}
