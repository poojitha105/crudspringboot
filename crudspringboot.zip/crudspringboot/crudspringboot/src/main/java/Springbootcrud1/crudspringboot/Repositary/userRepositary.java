package Springbootcrud1.crudspringboot.Repositary;

import Springbootcrud1.crudspringboot.Entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;


public interface userRepositary extends JpaRepository<Users ,Integer> {
}
