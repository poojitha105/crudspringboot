package Springbootcrud1.crudspringboot.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name="USER")
@Data
public class Users {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="UID")
    private int uid;
    @Column(name="UNAME")
    private String uname;
    @Column(name="PWD")
    private String pwd;

}
