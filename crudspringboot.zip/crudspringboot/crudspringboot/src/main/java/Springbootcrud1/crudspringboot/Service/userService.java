package Springbootcrud1.crudspringboot.Service;

import Springbootcrud1.crudspringboot.Entity.Users;

import java.util.List;

public interface userService {
    String addUser(Users u);
    List<Users> getUsesr();
    String updateUser(Users u);
    String deleteUser(int uid);
}
