package Springbootcrud1.crudspringboot.Controller;

import Springbootcrud1.crudspringboot.Entity.Users;
import Springbootcrud1.crudspringboot.Service.userServiceimp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/userinfo")
public class userController {
    @Autowired
    private userServiceimp us;

    public userController(userServiceimp us) {
        this.us = us;
    }

    @PostMapping("/adduser")
    public String addUser(@RequestBody Users u) {
        us.addUser(u);
        return "CREATED";
    }

    @GetMapping("/users")
    public List<Users> getUsesr() {

        return us.getUsesr();


    }
    @PutMapping("/update")
    public String updateUser(Users u){
        us.updateUser(u);
        return "UPDATED";

    }
    @DeleteMapping("/delete/{uid}")
    public String deleteuser(@PathVariable int uid)
    {
        us.deleteUser(uid);
        return "DELETED";
    }

}
