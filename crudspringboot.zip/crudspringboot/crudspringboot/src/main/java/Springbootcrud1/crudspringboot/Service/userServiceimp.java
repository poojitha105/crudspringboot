package Springbootcrud1.crudspringboot.Service;

import Springbootcrud1.crudspringboot.Entity.Users;
import Springbootcrud1.crudspringboot.Repositary.userRepositary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class userServiceimp implements userService{
    @Autowired
    private userRepositary ur;

    public userServiceimp(userRepositary ur) {
        this.ur = ur;
    }

    @Override
    public String addUser(Users u) {
        ur.save(u);
        return "CREATED";
    }

    @Override
    public List<Users> getUsesr() {
        List<Users> lu=ur.findAll();
        return lu;
    }

    @Override
    public String updateUser(Users u) {
        ur.save(u);
        return "UPDATED";
    }

    @Override
    public String deleteUser(int uid) {
        ur.deleteById(uid);
        return "DELETED";
    }
}
