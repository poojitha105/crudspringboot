package Springbootcrud1.crudspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
