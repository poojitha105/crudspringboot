package com.example.auth.controller;

import com.example.auth.model.Owner;
import com.example.auth.service.OwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/owner")
public class OwnerAuthController {

    @Autowired
    private OwnerService ownerService;

    @PostMapping("/register")
    public Owner register(@RequestBody Owner owner) {
        return ownerService.registerOwner(owner.getName(), owner.getEmail(), owner.getPassword());
    }

    @PostMapping("/login")
    public Owner login(@RequestBody Owner owner) {
        return ownerService.authenticateOwner(owner.getEmail(), owner.getPassword());
    }

    @PostMapping("/forgot-password")
    public String forgotPassword(@RequestParam String email) {
        String token = "123456"; // Simulate token generation
        ownerService.updateResetPasswordToken(token, email);
        return "Reset token set: " + token;
    }

    @PostMapping("/reset-password")
    public String resetPassword(@RequestParam String token, @RequestParam String newPassword) {
        Owner owner = ownerService.getByResetPasswordToken(token);
        if (owner == null) {
            return "Invalid token";
        }
        ownerService.updatePassword(owner, newPassword);
        return "Password updated successfully";
    }
}
