package com.example.auth.service;

import com.example.auth.model.Owner;
import com.example.auth.repository.OwnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OwnerService {

    @Autowired
    private OwnerRepository ownerRepository;

    // Removed BCryptPasswordEncoder

    public Owner registerOwner(String name, String email, String password) {
        if (ownerRepository.findByEmail(email.toLowerCase()) != null) {
            throw new RuntimeException("Email already registered");
        }
        Owner owner = new Owner();
        owner.setName(name);
        owner.setEmail(email.toLowerCase());
        owner.setPassword(password); // Plain text (not secure)
        return ownerRepository.save(owner);
    }

    public Owner authenticateOwner(String email, String password) {
        Owner owner = ownerRepository.findByEmail(email.toLowerCase());
        if (owner == null || !password.equals(owner.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }
        return owner;
    }

    public void updateResetPasswordToken(String token, String email) {
        Owner owner = ownerRepository.findByEmail(email.toLowerCase());
        if (owner == null) throw new RuntimeException("No owner found with this email");
        owner.setResetPasswordToken(token);
        ownerRepository.save(owner);
    }

    public Owner getByResetPasswordToken(String token) {
        return ownerRepository.findByResetPasswordToken(token);
    }

    public void updatePassword(Owner owner, String newPassword) {
        owner.setPassword(newPassword); // Plain text (not secure)
        owner.setResetPasswordToken(null);
        ownerRepository.save(owner);
    }
}
